// This example code demonstrates how to mix C and assembly code.
// It includes an example of a function that passes a variable to an assembly routine and receives a modified variable back from the assembly routine.
// Additionally, it shows how to interact with peripheral registers using assembly.
// Also includes two simple assembly functions: one to turn an LED on and another to turn the LED off.

#include "debug.h"

// Declaration of the C functions
void gpio_init(void);

// Declaration of the assembly functions in asm_function.S
extern uint16_t asm_function();
extern uint16_t asm_gpio_on();
extern uint16_t asm_gpio_off();

int main(void){

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    SystemInit();
    Delay_Init();
    gpio_init();
    USART_Printf_Init(115200);

    printf("SystemClk:%d\r\n",SystemCoreClock);
    printf( "ChipID:%08x\r\n", DBGMCU_GetCHIPID() );


    while(1){

        uint16_t value = 42;                    // We send this int to ASM function
        uint16_t result = asm_function(value);  // call the ASM routine asm_function, pass the int value to ASM routine and get the return value back.
        printf("The result is: %d\n", result);  // print the return value of the asm function, is should now be 62

        asm_gpio_on();  // Call the ASM routine asm_gpio_on
        Delay_Ms(100);
        asm_gpio_off(); // Call the ASM routine asm_gpio_off
        Delay_Ms(100);
    }
}

// C Functions
// We initial the GPIO peripherals in C, that is often much easier than in ASM
void gpio_init(void){

    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}
